from django import forms
from .models import Post


class PostForm(forms.ModelForm):
    title = forms.CharField(
        max_length=200,
        widget=forms.TextInput(attrs={'placeholder': 'What did you learn today?'})
    )
    body = forms.CharField(
        widget=forms.Textarea(attrs={
            'placeholder': 'Write it out — even a few sentences counts...',
            'rows': 8,
        })
    )

    class Meta:
        model  = Post
        fields = ['title', 'body']
