from django.urls import path
from . import views

urlpatterns = [
    path('post/new/',          views.post_create, name='post_create'),
    path('post/<int:pk>/',     views.post_detail, name='post_detail'),
    path('post/<int:pk>/del/', views.post_delete, name='post_delete'),
]
