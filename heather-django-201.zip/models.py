from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from sorl.thumbnail import ImageField


class Profile(models.Model):
    user         = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar       = ImageField(upload_to='avatars/', blank=True, null=True)
    followers    = models.ManyToManyField(User, related_name='following', blank=True)
    bio          = models.TextField(blank=True, max_length=300)
    created_at   = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} profile'

    @property
    def follower_count(self):
        return self.followers.count()

    @property
    def following_count(self):
        return Profile.objects.filter(followers=self.user).count()


# Auto-create / save profile whenever a User is saved
@receiver(post_save, sender=User)
def create_or_save_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)
    else:
        instance.profile.save()
