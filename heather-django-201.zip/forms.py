from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import PasswordChangeForm
from .models import Profile


class ProfileForm(forms.ModelForm):
    """Updates User first/last name, username, email + Profile avatar."""
    first_name = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'placeholder': 'Jane'}))
    last_name  = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'placeholder': 'Doe'}))
    username   = forms.CharField(max_length=150, widget=forms.TextInput(attrs={'placeholder': 'janedoe'}))
    email      = forms.EmailField(required=False, widget=forms.EmailInput(attrs={'placeholder': 'jane@example.com'}))

    class Meta:
        model  = Profile
        fields = ['avatar']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user')
        super().__init__(*args, **kwargs)
        # Pre-populate from User model
        self.fields['first_name'].initial = self.user.first_name
        self.fields['last_name'].initial  = self.user.last_name
        self.fields['username'].initial   = self.user.username
        self.fields['email'].initial      = self.user.email

    def clean_username(self):
        username = self.cleaned_data['username']
        if User.objects.exclude(pk=self.user.pk).filter(username=username).exists():
            raise forms.ValidationError("That username is already taken.")
        return username

    def save(self, commit=True):
        profile = super().save(commit=False)
        self.user.first_name = self.cleaned_data['first_name']
        self.user.last_name  = self.cleaned_data['last_name']
        self.user.username   = self.cleaned_data['username']
        self.user.email      = self.cleaned_data['email']
        if commit:
            self.user.save()
            profile.save()
        return profile


class CustomPasswordChangeForm(PasswordChangeForm):
    old_password  = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'current-password'}))
    new_password1 = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}))
    new_password2 = forms.CharField(widget=forms.PasswordInput(attrs={'autocomplete': 'new-password'}))
