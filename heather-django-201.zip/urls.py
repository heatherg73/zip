from django.urls import path
from . import views

urlpatterns = [
    path('',          views.home,             name='home'),
    path('settings/', views.account_settings, name='account_settings'),
]
