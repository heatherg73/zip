from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from .forms import ProfileForm, CustomPasswordChangeForm


@login_required
def account_settings(request):
    profile = request.user.profile

    if request.method == 'POST':
        form_type = request.POST.get('form_type')

        # ── Profile / avatar update ──
        if form_type == 'profile':
            form = ProfileForm(
                request.POST,
                request.FILES,
                instance=profile,
                user=request.user,
            )
            if form.is_valid():
                form.save()
                messages.success(request, 'Profile updated successfully.')
                return redirect('account_settings')
            else:
                messages.error(request, 'Please fix the errors below.')

        # ── Password change ──
        elif form_type == 'password':
            pw_form = CustomPasswordChangeForm(user=request.user, data=request.POST)
            if pw_form.is_valid():
                pw_form.save()
                update_session_auth_hash(request, pw_form.user)  # keep logged in
                messages.success(request, 'Password changed successfully.')
                return redirect('account_settings')
            else:
                for field, errors in pw_form.errors.items():
                    for error in errors:
                        messages.error(request, error)

        # ── Delete account ──
        elif form_type == 'delete':
            request.user.delete()
            messages.success(request, 'Your account has been deleted.')
            return redirect('home')

    return render(request, 'account/settings.html', {
        'profile': profile,
    })


def home(request):
    """Home / feed view."""
    from django.contrib.auth.models import User

    posts          = []   # Replace with your actual Post queryset, e.g. Post.objects.order_by('-created_at')[:20]
    til_count      = 0
    follower_count = 0
    following_count= 0
    streak         = 0

    if request.user.is_authenticated:
        profile        = request.user.profile
        follower_count = profile.follower_count
        following_count= profile.following_count
        # til_count    = Post.objects.filter(user=request.user).count()

    return render(request, 'home.html', {
        'posts':           posts,
        'til_count':       til_count,
        'follower_count':  follower_count,
        'following_count': following_count,
        'streak':          streak,
    })
