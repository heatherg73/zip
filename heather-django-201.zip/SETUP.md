# TIL — Account System Setup Guide

## Files included

```
accounts/
  models.py         ← Profile model (avatar, followers M2M)
  forms.py          ← ProfileForm + CustomPasswordChangeForm
  views.py          ← account_settings + home views
  urls.py           ← URL patterns
  migrations/
    0001_initial.py ← Profile migration

templates/
  base.html               ← Polished dark base layout
  home.html               ← Home / feed with stats bar
  account/
    settings.html         ← Tabbed settings page (profile · password · danger)
    login.html            ← Styled sign-in page
    signup.html           ← Styled sign-up page
```

---

## 1 — Add `accounts` to INSTALLED_APPS

In `til/settings.py`:

```python
INSTALLED_APPS = [
    ...
    'accounts',
    'allauth',
    'allauth.account',
    'sorl.thumbnail',
]
```

---

## 2 — Configure allauth in settings.py

```python
AUTHENTICATION_BACKENDS = [
    'django.contrib.auth.backends.ModelBackend',
    'allauth.account.auth_backends.AuthenticationBackend',
]

LOGIN_REDIRECT_URL  = '/'
LOGOUT_REDIRECT_URL = '/'
ACCOUNT_EMAIL_REQUIRED      = True
ACCOUNT_USERNAME_REQUIRED   = True
ACCOUNT_LOGIN_ON_SIGNUP     = True
```

---

## 3 — Configure TEMPLATES so Django finds your templates folder

```python
TEMPLATES = [{
    ...
    'DIRS': [BASE_DIR / 'templates'],
    ...
}]
```

---

## 4 — Media files (for avatar uploads)

```python
MEDIA_URL  = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'
```

In your **root `urls.py`**:

```python
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    ...
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

---

## 5 — Wire up URLs in `til/urls.py`

```python
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),   # allauth (login, signup, etc.)
    path('', include('accounts.urls')),           # home + settings
]
```

---

## 6 — Run migrations

```bash
python manage.py makemigrations accounts
python manage.py migrate
```

---

## 7 — Follower count in the home view

The `home` view in `accounts/views.py` already reads `profile.follower_count`
(a property on the Profile model). It passes `follower_count` to `home.html`.

To **add a follower**, use the M2M field:

```python
# Follow someone
target_profile.followers.add(request.user)

# Unfollow
target_profile.followers.remove(request.user)
```

---

## Notes

- `sorl-thumbnail` handles avatar resizing. Make sure `THUMBNAIL_KVSTORE` is set if you want Redis caching.
- The settings page is tabbed (Profile / Password / Danger zone) and fully mobile-responsive.
- Avatar previews update client-side before form submission via the FileReader API.
- Password strength meter runs entirely in JS with no dependencies.
