"""
Custom Wagtail admin hooks.
"""
from wagtail import hooks
from wagtail.snippets.views.snippets import SnippetViewSet, SnippetViewSetGroup
from .models import MenuItem, Testimonial


class MenuItemViewSet(SnippetViewSet):
    model = MenuItem
    icon = 'list-ul'
    list_display = ['title', 'page', 'url', 'order']
    search_fields = ['title']


class TestimonialViewSet(SnippetViewSet):
    model = Testimonial
    icon = 'user'
    list_display = ['name', 'role']
    search_fields = ['name', 'quote']


class ContentSnippets(SnippetViewSetGroup):
    items = [MenuItemViewSet, TestimonialViewSet]
    menu_icon = 'snippet'
    menu_label = 'Content Snippets'
    menu_order = 300
