"""
Core Wagtail CMS models.

Includes:
- HomePage, StandardPage, BlogIndexPage, BlogPage
- Rich text, StreamField with multiple block types
- ChooserBlocks, StaticBlocks
- ContactFormPage
- SiteSettings (wagtail.contrib.settings)
"""

from django.db import models
from django.utils.translation import gettext_lazy as _

from modelcluster.fields import ParentalKey, ParentalManyToManyField
from modelcluster.contrib.taggit import ClusterTaggableManager
from taggit.models import TaggedItemBase

from wagtail.models import Page, TranslatableMixin, Locale
from wagtail.fields import RichTextField, StreamField
from wagtail.admin.panels import (
    FieldPanel, MultiFieldPanel, InlinePanel, TabbedInterface, ObjectList,
)
from wagtail.images.blocks import ImageChooserBlock
from wagtail.documents.blocks import DocumentChooserBlock
from wagtail.snippets.blocks import SnippetChooserBlock
from wagtail.snippets.models import register_snippet
from wagtail.contrib.forms.models import AbstractEmailForm, AbstractFormField
from wagtail.contrib.forms.panels import FormSubmissionsPanel
from wagtail.contrib.settings.models import BaseSiteSetting, register_setting
from wagtail.contrib.routable_page.models import RoutablePageMixin, path
from wagtail.search import index
from wagtail import blocks
from wagtail.images.models import Image


# ─── Stream Blocks ──────────────────────────────────────────────────────────

class HeadingBlock(blocks.StructBlock):
    """Heading with optional anchor ID."""
    level = blocks.ChoiceBlock(
        choices=[('h2', 'H2'), ('h3', 'H3'), ('h4', 'H4')],
        default='h2',
        label=_('Heading level'),
    )
    text = blocks.CharBlock(label=_('Heading text'))
    anchor_id = blocks.CharBlock(required=False, label=_('Anchor ID (optional)'))

    class Meta:
        template = 'blocks/heading_block.html'
        icon = 'title'
        label = _('Heading')


class RichTextBlock(blocks.RichTextBlock):
    """Full-featured rich text block."""
    class Meta:
        template = 'blocks/richtext_block.html'
        icon = 'doc-full'
        label = _('Rich Text')


class ImageBlock(blocks.StructBlock):
    """Image with caption and optional link."""
    image = ImageChooserBlock(label=_('Image'))
    caption = blocks.CharBlock(required=False, label=_('Caption'))
    attribution = blocks.CharBlock(required=False, label=_('Attribution'))
    alignment = blocks.ChoiceBlock(
        choices=[('left', _('Left')), ('center', _('Center')), ('right', _('Right')), ('full', _('Full width'))],
        default='center',
    )

    class Meta:
        template = 'blocks/image_block.html'
        icon = 'image'
        label = _('Image')


class QuoteBlock(blocks.StructBlock):
    """Pull quote block."""
    quote = blocks.TextBlock(label=_('Quote'))
    attribution = blocks.CharBlock(required=False, label=_('Attribution'))

    class Meta:
        template = 'blocks/quote_block.html'
        icon = 'openquote'
        label = _('Quote')


class CallToActionBlock(blocks.StructBlock):
    """CTA block with heading, text and button."""
    heading = blocks.CharBlock(label=_('Heading'))
    text = blocks.TextBlock(required=False, label=_('Body text'))
    button_text = blocks.CharBlock(label=_('Button text'))
    button_url = blocks.URLBlock(label=_('Button URL'))
    style = blocks.ChoiceBlock(
        choices=[('primary', _('Primary')), ('secondary', _('Secondary')), ('outline', _('Outline'))],
        default='primary',
    )

    class Meta:
        template = 'blocks/cta_block.html'
        icon = 'pick'
        label = _('Call to Action')


class CardBlock(blocks.StructBlock):
    """Individual card."""
    image = ImageChooserBlock(required=False, label=_('Image'))
    title = blocks.CharBlock(label=_('Title'))
    text = blocks.TextBlock(label=_('Text'))
    link = blocks.URLBlock(required=False, label=_('Link'))
    link_text = blocks.CharBlock(required=False, label=_('Link text'))


class CardsBlock(blocks.StructBlock):
    """Grid of cards."""
    heading = blocks.CharBlock(required=False, label=_('Section heading'))
    columns = blocks.ChoiceBlock(
        choices=[('2', '2 columns'), ('3', '3 columns'), ('4', '4 columns')],
        default='3',
    )
    cards = blocks.ListBlock(CardBlock(), label=_('Cards'))

    class Meta:
        template = 'blocks/cards_block.html'
        icon = 'grip'
        label = _('Cards Grid')


class AccordionItemBlock(blocks.StructBlock):
    """Single accordion item."""
    title = blocks.CharBlock(label=_('Title'))
    content = blocks.RichTextBlock(label=_('Content'))


class AccordionBlock(blocks.StructBlock):
    """Expandable accordion."""
    items = blocks.ListBlock(AccordionItemBlock(), label=_('Accordion items'))

    class Meta:
        template = 'blocks/accordion_block.html'
        icon = 'list-ul'
        label = _('Accordion')


class EmbedBlock(blocks.StructBlock):
    """Video or external embed."""
    url = blocks.URLBlock(label=_('Embed URL'))
    caption = blocks.CharBlock(required=False, label=_('Caption'))

    class Meta:
        template = 'blocks/embed_block.html'
        icon = 'media'
        label = _('Embed')


class DocumentBlock(blocks.StructBlock):
    """Downloadable document."""
    document = DocumentChooserBlock(label=_('Document'))
    title = blocks.CharBlock(required=False, label=_('Override title'))

    class Meta:
        template = 'blocks/document_block.html'
        icon = 'doc-full-inverse'
        label = _('Document Download')


# Static block — no editable fields, just renders a template
class SeparatorBlock(blocks.StaticBlock):
    class Meta:
        template = 'blocks/separator_block.html'
        icon = 'horizontalrule'
        label = _('Separator / Divider')
        admin_text = _('A horizontal separator line. No settings.')


class SpacerBlock(blocks.StaticBlock):
    class Meta:
        template = 'blocks/spacer_block.html'
        icon = 'arrows-up-down'
        label = _('Spacer')
        admin_text = _('Adds vertical spacing. No settings.')


class HeroBlock(blocks.StructBlock):
    """Hero / banner section."""
    heading = blocks.CharBlock(label=_('Heading'))
    subheading = blocks.CharBlock(required=False, label=_('Subheading'))
    image = ImageChooserBlock(required=False, label=_('Background image'))
    cta_text = blocks.CharBlock(required=False, label=_('CTA text'))
    cta_url = blocks.URLBlock(required=False, label=_('CTA URL'))
    overlay_opacity = blocks.ChoiceBlock(
        choices=[('0', 'None'), ('25', '25%'), ('50', '50%'), ('75', '75%')],
        default='50',
    )

    class Meta:
        template = 'blocks/hero_block.html'
        icon = 'image'
        label = _('Hero / Banner')


# Page chooser block (chooser block)
class RelatedPageBlock(blocks.StructBlock):
    page = blocks.PageChooserBlock(label=_('Page'))
    description = blocks.CharBlock(required=False, label=_('Override description'))

    class Meta:
        template = 'blocks/related_page_block.html'
        icon = 'doc-empty'
        label = _('Related Page')


class SnippetBlock(SnippetChooserBlock):
    pass


# ─── Main StreamField definition ────────────────────────────────────────────

CONTENT_BLOCKS = [
    ('heading', HeadingBlock()),
    ('rich_text', RichTextBlock(features=[
        'h2', 'h3', 'h4', 'bold', 'italic', 'ol', 'ul',
        'hr', 'link', 'document-link', 'image', 'embed',
        'blockquote', 'superscript', 'subscript', 'strikethrough', 'code',
    ])),
    ('image', ImageBlock()),
    ('quote', QuoteBlock()),
    ('cta', CallToActionBlock()),
    ('cards', CardsBlock()),
    ('accordion', AccordionBlock()),
    ('embed', EmbedBlock()),
    ('document', DocumentBlock()),
    ('hero', HeroBlock()),
    ('related_page', RelatedPageBlock()),
    ('separator', SeparatorBlock()),
    ('spacer', SpacerBlock()),
    ('raw_html', blocks.RawHTMLBlock(
        label=_('Raw HTML'),
        icon='code',
    )),
]


# ─── Snippets ────────────────────────────────────────────────────────────────

@register_snippet
class MenuItem(TranslatableMixin, models.Model):
    """Navigation menu item snippet."""
    title = models.CharField(max_length=255, verbose_name=_('Title'))
    page = models.ForeignKey(
        'wagtailcore.Page',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name=_('Page'),
    )
    url = models.URLField(blank=True, verbose_name=_('External URL'))
    open_in_new_tab = models.BooleanField(default=False, verbose_name=_('Open in new tab'))
    order = models.PositiveIntegerField(default=0)

    panels = [
        FieldPanel('title'),
        FieldPanel('page'),
        FieldPanel('url'),
        FieldPanel('open_in_new_tab'),
        FieldPanel('order'),
    ]

    class Meta:
        ordering = ['order', 'title']
        verbose_name = _('Menu Item')
        verbose_name_plural = _('Menu Items')
        unique_together = [('translation_key', 'locale')]

    def __str__(self):
        return self.title

    def get_url(self):
        if self.page:
            return self.page.url
        return self.url


@register_snippet
class Testimonial(TranslatableMixin, models.Model):
    """Testimonial snippet."""
    name = models.CharField(max_length=255)
    role = models.CharField(max_length=255, blank=True)
    quote = models.TextField()
    photo = models.ForeignKey(
        'wagtailimages.Image',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
    )

    panels = [
        FieldPanel('name'),
        FieldPanel('role'),
        FieldPanel('quote'),
        FieldPanel('photo'),
    ]

    class Meta:
        verbose_name = _('Testimonial')
        verbose_name_plural = _('Testimonials')
        unique_together = [('translation_key', 'locale')]

    def __str__(self):
        return f'{self.name} — {self.quote[:50]}'


# ─── Site Settings ────────────────────────────────────────────────────────────

@register_setting
class SiteSettings(BaseSiteSetting, TranslatableMixin):
    """Global site settings available in all templates."""
    site_logo = models.ForeignKey(
        'wagtailimages.Image',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name=_('Site logo'),
    )
    footer_text = RichTextField(blank=True, verbose_name=_('Footer text'))
    google_analytics_id = models.CharField(max_length=50, blank=True, verbose_name=_('Google Analytics ID'))
    facebook_url = models.URLField(blank=True)
    twitter_url = models.URLField(blank=True)
    instagram_url = models.URLField(blank=True)
    linkedin_url = models.URLField(blank=True)
    phone = models.CharField(max_length=50, blank=True)
    email = models.EmailField(blank=True)
    address = models.TextField(blank=True)

    panels = [
        FieldPanel('site_logo'),
        MultiFieldPanel([
            FieldPanel('footer_text'),
            FieldPanel('google_analytics_id'),
        ], heading=_('General')),
        MultiFieldPanel([
            FieldPanel('facebook_url'),
            FieldPanel('twitter_url'),
            FieldPanel('instagram_url'),
            FieldPanel('linkedin_url'),
        ], heading=_('Social Media')),
        MultiFieldPanel([
            FieldPanel('phone'),
            FieldPanel('email'),
            FieldPanel('address'),
        ], heading=_('Contact Info')),
    ]

    class Meta:
        verbose_name = _('Site Settings')
        unique_together = [('translation_key', 'locale')]


# ─── Pages ────────────────────────────────────────────────────────────────────

class HomePage(Page):
    """Home page with hero and stream content."""
    hero_title = models.CharField(max_length=255, verbose_name=_('Hero title'))
    hero_subtitle = models.CharField(max_length=500, blank=True, verbose_name=_('Hero subtitle'))
    hero_image = models.ForeignKey(
        'wagtailimages.Image',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name=_('Hero image'),
    )
    hero_cta_text = models.CharField(max_length=100, blank=True, verbose_name=_('CTA button text'))
    hero_cta_page = models.ForeignKey(
        'wagtailcore.Page',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name=_('CTA page'),
    )
    body = StreamField(CONTENT_BLOCKS, blank=True, use_json_field=True, verbose_name=_('Body'))

    content_panels = Page.content_panels + [
        MultiFieldPanel([
            FieldPanel('hero_title'),
            FieldPanel('hero_subtitle'),
            FieldPanel('hero_image'),
            FieldPanel('hero_cta_text'),
            FieldPanel('hero_cta_page'),
        ], heading=_('Hero Section')),
        FieldPanel('body'),
    ]

    search_fields = Page.search_fields + [
        index.SearchField('hero_title'),
        index.SearchField('hero_subtitle'),
    ]

    class Meta:
        verbose_name = _('Home Page')


class StandardPage(Page):
    """Generic content page."""
    intro = RichTextField(blank=True, verbose_name=_('Introduction'))
    body = StreamField(CONTENT_BLOCKS, blank=True, use_json_field=True, verbose_name=_('Body'))
    show_in_menus_default = True

    content_panels = Page.content_panels + [
        FieldPanel('intro'),
        FieldPanel('body'),
    ]

    search_fields = Page.search_fields + [
        index.SearchField('intro'),
        index.SearchField('body'),
    ]

    class Meta:
        verbose_name = _('Standard Page')


# ─── Blog ─────────────────────────────────────────────────────────────────────

class BlogTag(TaggedItemBase):
    content_object = ParentalKey('BlogPage', related_name='tagged_items', on_delete=models.CASCADE)


class BlogIndexPage(RoutablePageMixin, Page):
    """Blog listing page with routing."""
    intro = RichTextField(blank=True, verbose_name=_('Introduction'))

    content_panels = Page.content_panels + [
        FieldPanel('intro'),
    ]

    @path('')
    def index_route(self, request):
        from django.shortcuts import render
        posts = BlogPage.objects.live().descendant_of(self).order_by('-first_published_at')
        return render(request, 'core/blog_index_page.html', {
            'page': self,
            'posts': posts,
        })

    @path('tag/<str:tag>/')
    def tag_route(self, request, tag):
        from django.shortcuts import render
        posts = BlogPage.objects.live().descendant_of(self).filter(tags__name=tag)
        return render(request, 'core/blog_index_page.html', {
            'page': self,
            'posts': posts,
            'active_tag': tag,
        })

    class Meta:
        verbose_name = _('Blog Index Page')


class BlogPage(Page):
    """Individual blog post."""
    author = models.CharField(max_length=255, blank=True, verbose_name=_('Author'))
    date = models.DateField(verbose_name=_('Publication date'))
    intro = RichTextField(blank=True, verbose_name=_('Intro / Excerpt'))
    featured_image = models.ForeignKey(
        'wagtailimages.Image',
        null=True, blank=True,
        on_delete=models.SET_NULL,
        related_name='+',
        verbose_name=_('Featured image'),
    )
    body = StreamField(CONTENT_BLOCKS, use_json_field=True, verbose_name=_('Body'))
    tags = ClusterTaggableManager(through=BlogTag, blank=True)

    content_panels = Page.content_panels + [
        MultiFieldPanel([
            FieldPanel('author'),
            FieldPanel('date'),
            FieldPanel('tags'),
            FieldPanel('featured_image'),
        ], heading=_('Post metadata')),
        FieldPanel('intro'),
        FieldPanel('body'),
    ]

    search_fields = Page.search_fields + [
        index.SearchField('intro'),
        index.SearchField('body'),
        index.FilterField('date'),
    ]

    class Meta:
        ordering = ['-date']
        verbose_name = _('Blog Post')


# ─── Contact Form ─────────────────────────────────────────────────────────────

class ContactFormField(AbstractFormField):
    page = ParentalKey('ContactFormPage', on_delete=models.CASCADE, related_name='form_fields')


class ContactFormPage(AbstractEmailForm):
    """Contact form page using Wagtail's built-in form system."""
    intro = RichTextField(blank=True, verbose_name=_('Intro text'))
    thank_you_text = RichTextField(blank=True, verbose_name=_('Thank you message'))
    body = StreamField(CONTENT_BLOCKS, blank=True, use_json_field=True, verbose_name=_('Additional content'))

    content_panels = AbstractEmailForm.content_panels + [
        FieldPanel('intro'),
        InlinePanel('form_fields', label=_('Form fields')),
        FieldPanel('thank_you_text'),
        MultiFieldPanel([
            FieldPanel('from_address'),
            FieldPanel('to_address'),
            FieldPanel('subject'),
        ], heading=_('Email settings')),
        FieldPanel('body'),
        FormSubmissionsPanel(),
    ]

    class Meta:
        verbose_name = _('Contact Form Page')
